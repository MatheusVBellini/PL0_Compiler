#include "compiler_errors.h"

#include <stdio.h>
#include <string.h>

#include "lexical_analyzer/lexical_analyzer.h"
#include "syntactic_analyzer/syntactic_analyzer.h"
#include "utils/utils.h"

PL0_Error errors_table[] = {
    {ERR_NO_FINAL_PERIOD, "Expected a period at the end of the program"},
    {ERR_COMMENT_NOT_CLOSED, "Comment not closed"},
    {ERR_UNEXPECTED_EOF, "Unexpected end of file"},
    {ERR_LEXICAL_INVALID_SYMBOL, "Invalid symbol"},
    {ERR_LEXICAL_INVALID_NUMBER, "Invalid number"},
    {ERR_LEXICAL_INVALID_IDENTIFIER, "Invalid identifier"},
    {ERR_SYNTACTICAL_MISSING_SEMICOLON, "Missing semicolon `;` before this token"},
    {ERR_SYNTACTICAL_MISSING_EQUAL_SYMBOL, "Missing equal `=` symbol before this token"},
    {ERR_SYNTACTICAL_MISSING_END_SYMBOL, "Missing `END` symbol before this token"},
    {ERR_SYNTACTICAL_MISSING_THEN_SYMBOL, "Missing `THEN` symbol before this token"},
    {ERR_SYNTACTICAL_MISSING_DO_SYMBOL, "Missing `DO` symbol before this token"},
    {ERR_SYNTACTICAL_MISSING_RIGHT_PARENTHESIS, "Missing right parenthesis `)` before this token"},
    {ERR_SYNTACTICAL_MISSING_LEFT_PARENTHESIS, "Missing left parenthesis `(` before this token"},
    {ERR_SYNTACTICAL_MISSING_RELATIONAL_OPERATOR, "Missing relational operator `=`, `<>`, `<`, `>`, `<=`, `>=` before this token"},
    {ERR_SYNTACTICAL_MISSING_EXPRESSION_NUMBER_OR_IDENTIFIER, "Missing expression, number or identifier before this token"},
    {ERR_SYNTACTICAL_MISSING_CONDITION, "Missing condition before this token"}
};

// crie uma funcao que pega um codigo de erro e retorna uma mensagem de erro
char* get_error_message(int error_code) {
    for (long unsigned int i = 0; i < sizeof(errors_table) / sizeof(errors_table[0]); i++) {
        if (errors_table[i].code == error_code) {
            return errors_table[i].message;
        }
    }
    return "Unknown error";
}

void throw_error(int error_code, Compiler_state* s) {
    Input_info* inp = s->input_info;
    s->error_count++;

    // print without line number
    if (inp->current_line <= 0 || inp->line == NULL) {
        if (s->flags->test_mode) {
            printf("error: %s\n", get_error_message(error_code));
            return;
        }

        printf("\033[1;31merror:\033[0m %s\n", get_error_message(error_code));
        return;
    }

    if (s->flags->test_mode) {
        printf("%d:%d error: %s\n", inp->current_line, inp->line_pos, get_error_message(error_code));
        return;
    }

    size_t token_len = 0;
    if (s->token != NULL) {
        token_len = strlen(s->token->value);
    }

    // print with line number and the line content
    printf("\033[1m%s:%d:%d:\033[1;31m error:\033[0m %s\n", inp->file_name, inp->current_line, inp->line_pos, get_error_message(error_code));

    // Print the line with the token highlighted in red
    printf("  %02d |\t", inp->current_line);
    for (size_t i = 0; i < inp->line_pos - token_len; i++) {
        printf("%c", inp->line[i]);
    }

    if (s->token != NULL) {
        printf("\033[1;31m%s\033[0m", s->token->value);
    }
    printf("%s", inp->line + inp->line_pos);

    // if line not ended with \n, print it
    size_t line_len = strlen(inp->line);
    if (inp->line[line_len - 1] != '\n') {
        printf("\n");
    }

    printf("     |\t");

    if (s->token == NULL) {
        token_len++;  // It just works
    }

    // Print the caret pointing to the error position (line_pos - token_len)
    for (size_t i = 0; i < inp->line_pos - token_len; i++) {
        if (inp->line[i] == '\t') {
            printf("\t");  // handle tabs properly
        } else {
            printf(" ");
        }
    }

    if (s->token == NULL) {
        token_len--;  // It just works
    }

    // Print the caret
    printf("\033[1;31m^\033[0m");

    // Print the ~
    for (size_t i = 1; i < token_len; i++) {
        printf("\033[1;31m~\033[0m");
    }

    printf("\n");
}

void panic_mode(Compiler_state* state, int sync_type) {
    if (!state->token) {
        return;  // No token to synchronize
    }
    if (state->token->type == symbol_error) {
        get_next_token(state);
    }

    // Keep reading tokens until a sync token is found
    while (!is_sync_token(state->token->type, sync_type)) {
        get_next_token(state);
        if (state->token->type == symbol_error) {
            continue;
        }

        // If the token is NULL, we reached the end of the file
        if (state->token == NULL) {
            return;
        }
    }

    if (state->token->type == symbol_comma){
        if (sync_type == 1) {
            PROC_mais_const(state);
        } else if (sync_type == 2) {
            PROC_mais_var(state);
            if (is_equal_token_types(state->token, symbol_semicolon)) {
                get_next_token(state);
            } else {
                throw_error(ERR_SYNTACTICAL_MISSING_SEMICOLON, state);
                panic_mode(state, 0);
            }
        }
        return;
    } else if (state->token->type == symbol_keyword) {
        if (sync_type == 3){
            PROC_procedimento(state);
        } else if (sync_type == 4){
            PROC_bloco(state);
        } else if (sync_type == 5) {
            PROC_comando(state);
        }
        return;
    } else if (state->token->type == symbol_identifier) {
        if (sync_type == 6) {
            PROC_expressao(state);
        }
        return;
    }
    return;
}

int is_sync_token(token_type type, int sync_type) {
    token_type sync_tokens[5];
    int num_sync_tokens = 0;
    switch (sync_type) {
        case 0: // No sync token
            sync_tokens[0] = symbol_semicolon;
            sync_tokens[1] = symbol_period;
            sync_tokens[2] = symbol_keyword;
            num_sync_tokens = 3;
            break;
        case 1: // If is looking for more constants
            sync_tokens[0] = symbol_comma;
            sync_tokens[1] = symbol_identifier;
            sync_tokens[2] = symbol_semicolon;
            sync_tokens[3] = symbol_period;
            sync_tokens[4] = symbol_keyword;
            num_sync_tokens = 5;
            break;
        case 2: // If is looking for more variables
            sync_tokens[0] = symbol_comma;
            sync_tokens[1] = symbol_identifier;
            sync_tokens[2] = symbol_semicolon;
            sync_tokens[3] = symbol_period;
            sync_tokens[4] = symbol_keyword;
            num_sync_tokens = 5;
            break;
        case 3: // If is looking for more procedures
            sync_tokens[0] = symbol_keyword;
            sync_tokens[1] = symbol_semicolon;
            sync_tokens[2] = symbol_period;
            num_sync_tokens = 3;
            break;
        case 4: // If is looking for more blocks
            sync_tokens[0] = symbol_keyword;
            sync_tokens[1] = symbol_semicolon;
            sync_tokens[2] = symbol_period;
            num_sync_tokens = 3;
            break;
        case 5: // If is looking for more commands
            sync_tokens[0] = symbol_keyword;
            sync_tokens[1] = symbol_semicolon;
            sync_tokens[2] = symbol_period;
            num_sync_tokens = 3;
            break;
        case 6: // If is looking for more expressions
            sync_tokens[0] = symbol_identifier;
            sync_tokens[1] = symbol_rparen;
            sync_tokens[2] = symbol_semicolon;
            sync_tokens[3] = symbol_keyword;
            sync_tokens[4] = symbol_period;
            num_sync_tokens = 5;
            break;
    }
    for (int i = 0; i < num_sync_tokens; i++) {
        if (type == sync_tokens[i]) {
            return 1;
        }
    }
    return 0;
}