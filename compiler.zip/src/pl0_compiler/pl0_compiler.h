#ifndef PL0_COMPILER_H
#define PL0_COMPILER_H

#include <stdio.h>

void PL0_compiler(FILE* file, int argc, char* argv[]);

#endif